package com.brucetify

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.OpenableColumns
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.io.File
import java.net.Inet4Address
import java.net.NetworkInterface
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private lateinit var info: TextView
    private lateinit var list: LinearLayout
    private lateinit var toggle: Button

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        Server.dir = File(filesDir, "music").apply { mkdirs() }

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(32, 32, 32, 32) }
        info = TextView(this).apply { textSize = 16f }
        toggle = Button(this).apply { setOnClickListener { toggleServer() } }
        val add = Button(this).apply { text = "Agregar canciones"; setOnClickListener { pick() } }
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(info)
        root.addView(toggle)
        root.addView(add)
        root.addView(ScrollView(this).apply { addView(list) })
        setContentView(root)

        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun ips(): String = try {
        NetworkInterface.getNetworkInterfaces().toList()
            .flatMap { it.inetAddresses.toList() }
            .filter { it is Inet4Address && !it.isLoopbackAddress && it.isSiteLocalAddress }
            .mapNotNull { it.hostAddress }.distinct().joinToString("  /  ").ifEmpty { "sin WiFi" }
    } catch (e: Exception) {
        "?"
    }

    private fun refresh() {
        toggle.text = if (Server.running) "Detener servidor" else "Iniciar servidor"
        info.text = (if (Server.running) "Servidor ACTIVO\n" else "Servidor detenido\n") +
            "En el M5 usa:  http://" + ips() + ":" + Server.PORT +
            "\n\nMantén pulsada una canción para borrarla."
        list.removeAllViews()
        for (f in Server.songs()) {
            list.addView(TextView(this).apply {
                text = "♪  " + f.nameWithoutExtension
                textSize = 18f
                setPadding(0, 24, 0, 24)
                setOnLongClickListener {
                    AlertDialog.Builder(this@MainActivity).setMessage("¿Borrar ${f.name}?")
                        .setPositiveButton("Borrar") { _, _ -> f.delete(); refresh() }
                        .setNegativeButton("Cancelar", null).show()
                    true
                }
            })
        }
    }

    private fun toggleServer() {
        val i = Intent(this, BruceService::class.java)
        if (Server.running) stopService(i) else startForegroundService(i)
        list.postDelayed({ refresh() }, 500)
    }

    private fun pick() {
        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "audio/*"
            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
        }, 7)
    }

    override fun onActivityResult(rc: Int, res: Int, d: Intent?) {
        super.onActivityResult(rc, res, d)
        if (rc != 7 || res != RESULT_OK || d == null) return
        val uris = mutableListOf<Uri>()
        val clip = d.clipData
        if (clip != null) for (i in 0 until clip.itemCount) uris.add(clip.getItemAt(i).uri)
        else d.data?.let { uris.add(it) }
        info.text = "Copiando ${uris.size} archivo(s)..."
        thread {
            for (u in uris) copy(u)
            runOnUiThread { refresh() }
        }
    }

    private fun copy(u: Uri) {
        try {
            var name = "cancion_${System.currentTimeMillis()}.mp3"
            contentResolver.query(u, null, null, null, null)?.use { c ->
                val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (i >= 0 && c.moveToFirst()) name = c.getString(i)
            }
            name = name.replace(Regex("[^\\w. -]"), "_")
            contentResolver.openInputStream(u)?.use { ins ->
                File(Server.dir, name).outputStream().use { ins.copyTo(it) }
            }
        } catch (_: Exception) {
        }
    }
}
