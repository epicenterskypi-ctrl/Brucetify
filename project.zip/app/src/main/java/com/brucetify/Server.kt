package com.brucetify

import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import java.io.ByteArrayOutputStream
import java.io.File
import java.net.ServerSocket
import java.net.Socket
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.text.Normalizer
import kotlin.concurrent.thread

/** Servidor HTTP minimo: misma API que brucetify_server.py (lista + trozos WAV 11 kHz mono). */
object Server {
    const val PORT = 8080
    const val RATE = 11025
    const val CHUNK_SEC = 30
    const val PART = 65536

    lateinit var dir: File
    @Volatile private var sock: ServerSocket? = null
    private val durations = HashMap<String, Double>()
    private var cacheKey = ""
    private var cacheData = ByteArray(0)

    val running: Boolean get() = sock != null

    fun songs(): List<File> = (dir.listFiles() ?: emptyArray()).filter { it.isFile }.sortedBy { it.name }

    fun title(f: File): String =
        Normalizer.normalize(f.nameWithoutExtension, Normalizer.Form.NFKD)
            .replace(Regex("[^\\x20-\\x7E]"), "").replace("|", " ").trim().take(40).ifEmpty { "cancion" }

    private fun seconds(f: File): Double = durations.getOrPut(f.name + f.lastModified()) {
        val r = MediaMetadataRetriever()
        try {
            r.setDataSource(f.path)
            (r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toDoubleOrNull() ?: 0.0) / 1000.0
        } catch (e: Exception) {
            0.0
        } finally {
            r.release()
        }
    }

    @Synchronized fun listText(): String {
        val sb = StringBuilder("#part|$PART\n")
        songs().forEachIndexed { i, f ->
            val s = seconds(f)
            val chunks = maxOf(1, Math.ceil(s / CHUNK_SEC).toInt())
            sb.append("$i|${title(f)}|$chunks|${s.toInt()}\n")
        }
        return sb.toString()
    }

    @Synchronized fun render(f: File, n: Int): ByteArray {
        val key = f.name + f.lastModified() + ":" + n
        if (key == cacheKey) return cacheData
        val pcm = decode(f, n.toLong() * CHUNK_SEC * 1_000_000L, (n + 1L) * CHUNK_SEC * 1_000_000L)
        val h = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
        h.put("RIFF".toByteArray()).putInt(36 + pcm.size).put("WAVEfmt ".toByteArray()).putInt(16)
        h.putShort(1).putShort(1).putInt(RATE).putInt(RATE * 2).putShort(2).putShort(16)
        h.put("data".toByteArray()).putInt(pcm.size)
        cacheData = h.array() + pcm
        cacheKey = key
        return cacheData
    }

    private fun emit(o: ByteArrayOutputStream, sum: Long, cnt: Int) {
        if (cnt == 0) return
        val v = (sum / cnt).toInt().coerceIn(-32768, 32767)
        o.write(v and 0xFF)
        o.write((v shr 8) and 0xFF)
    }

    /** Decodifica [startUs, endUs) a PCM 16-bit mono de 11025 Hz. */
    private fun decode(f: File, startUs: Long, endUs: Long): ByteArray {
        val ex = MediaExtractor()
        ex.setDataSource(f.path)
        var ti = -1
        for (i in 0 until ex.trackCount) {
            if (ex.getTrackFormat(i).getString(MediaFormat.KEY_MIME)!!.startsWith("audio/")) { ti = i; break }
        }
        if (ti < 0) { ex.release(); return ByteArray(0) }
        ex.selectTrack(ti)
        val fmt = ex.getTrackFormat(ti)
        val codec = MediaCodec.createDecoderByType(fmt.getString(MediaFormat.KEY_MIME)!!)
        codec.configure(fmt, null, null, 0)
        codec.start()
        ex.seekTo(startUs, MediaExtractor.SEEK_TO_PREVIOUS_SYNC)

        var rate = fmt.getInteger(MediaFormat.KEY_SAMPLE_RATE)
        var ch = fmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
        val out = ByteArrayOutputStream()
        val info = MediaCodec.BufferInfo()
        var inDone = false
        var done = false
        var rel = 0L
        var curIdx = 0L
        var sum = 0L
        var cnt = 0
        try {
            while (!done) {
                if (!inDone) {
                    val ii = codec.dequeueInputBuffer(10_000)
                    if (ii >= 0) {
                        val sz = ex.readSampleData(codec.getInputBuffer(ii)!!, 0)
                        if (sz < 0) {
                            codec.queueInputBuffer(ii, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inDone = true
                        } else {
                            codec.queueInputBuffer(ii, 0, sz, ex.sampleTime, 0)
                            ex.advance()
                        }
                    }
                }
                val oi = codec.dequeueOutputBuffer(info, 10_000)
                if (oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    val of = codec.outputFormat
                    rate = of.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                    ch = of.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                } else if (oi >= 0) {
                    val sb = codec.getOutputBuffer(oi)!!.order(ByteOrder.LITTLE_ENDIAN).asShortBuffer()
                    val frames = info.size / (2 * ch)
                    var fi = 0
                    while (fi < frames && !done) {
                        val t = info.presentationTimeUs + fi * 1_000_000L / rate
                        if (t >= endUs) {
                            done = true
                        } else if (t >= startUs) {
                            var s = 0
                            for (c in 0 until ch) s += sb.get(fi * ch + c)
                            val idx = rel * RATE / rate
                            if (idx != curIdx) { emit(out, sum, cnt); curIdx = idx; sum = 0; cnt = 0 }
                            sum += s / ch
                            cnt++
                            rel++
                        }
                        fi++
                    }
                    codec.releaseOutputBuffer(oi, false)
                    if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) done = true
                }
            }
            emit(out, sum, cnt)
        } finally {
            codec.stop(); codec.release(); ex.release()
        }
        return out.toByteArray()
    }

    fun start() {
        if (sock != null) return
        val s = ServerSocket(PORT)
        sock = s
        thread(isDaemon = true) {
            while (!s.isClosed) {
                try {
                    val c = s.accept()
                    thread { handle(c) }
                } catch (e: Exception) {
                    break
                }
            }
        }
    }

    fun stop() {
        try { sock?.close() } catch (_: Exception) {}
        sock = null
    }

    private fun handle(c: Socket) {
        c.use {
            try {
                val br = c.getInputStream().bufferedReader()
                val line = br.readLine() ?: return
                while (true) { val h = br.readLine(); if (h == null || h.isEmpty()) break }
                val path = line.split(" ").getOrElse(1) { "/" }
                var code = 200
                var body = ByteArray(0)
                val m = Regex("/song/(\\d+)/(\\d+)/(\\d+)").matchEntire(path)
                if (path == "/api/list") {
                    body = listText().toByteArray()
                } else if (m != null) {
                    val v = m.groupValues
                    val f = songs().getOrNull(v[1].toInt())
                    if (f == null) {
                        code = 404
                    } else {
                        val d = render(f, v[2].toInt())
                        val p = v[3].toInt()
                        body = if (p * PART >= d.size) ByteArray(0) else d.copyOfRange(p * PART, minOf(d.size, (p + 1) * PART))
                    }
                } else if (path == "/") {
                    body = "Brucetify".toByteArray()
                } else {
                    code = 404
                }
                val o = c.getOutputStream()
                o.write("HTTP/1.0 $code X\r\nContent-Length: ${body.size}\r\nContent-Type: application/octet-stream\r\nConnection: close\r\n\r\n".toByteArray())
                o.write(body)
                o.flush()
            } catch (_: Exception) {
            }
        }
    }
}
