package com.brucetify

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.wifi.WifiManager
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import java.io.File

class BruceService : Service() {
    private var wl: PowerManager.WakeLock? = null
    private var wifi: WifiManager.WifiLock? = null

    override fun onBind(i: Intent?): IBinder? = null

    @Suppress("DEPRECATION")
    override fun onStartCommand(i: Intent?, flags: Int, startId: Int): Int {
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel("bt", "Brucetify", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "bt")
            .setContentTitle("Brucetify activo")
            .setContentText("Sirviendo canciones en el puerto ${Server.PORT}")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        else startForeground(1, n)

        Server.dir = File(filesDir, "music").apply { mkdirs() }
        try { Server.start() } catch (_: Exception) {}

        if (wl == null) {
            wl = getSystemService(PowerManager::class.java)
                .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "brucetify:wl").apply { acquire() }
            wifi = (applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager)
                .createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF, "brucetify:wifi").apply { acquire() }
        }
        return START_STICKY
    }

    override fun onDestroy() {
        Server.stop()
        try { wl?.release() } catch (_: Exception) {}
        try { wifi?.release() } catch (_: Exception) {}
        wl = null
        wifi = null
        super.onDestroy()
    }
}
